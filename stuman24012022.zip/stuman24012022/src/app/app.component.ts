import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {


  ngOnInit(): void {

    window.addEventListener("scroll", function(){
      var header = document.querySelector("header");
      header!.classList.toggle('sticky', window.scrollY > 0);
    });

    
    const menu = document.querySelector('.menu');
    const menuBtn = document.querySelector('.menu-btn');
    const closeBtn = document.querySelector('.close-btn');
    

    menuBtn!.addEventListener("click", () => {
      menu!.classList.add('active');
    });

    closeBtn!.addEventListener("click", () => {
      menu!.classList.remove('active');
    });

    


    
  }
  
  
}
