import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormComponent } from '../form/form.component';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  registerForm: FormGroup | any;
    submitted = false;

  constructor(private formBuilder: FormBuilder,private router: Router) { }

  ngOnInit(): void {

    this.registerForm = this.formBuilder.group({
      
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(6)]],
      
  });
  }
  get f() { return this.registerForm.controls; }

  btnClick=  () => {
    this.submitted=true;
    if(this.registerForm.invalid){
      return;
    }
   
    


    this.router.navigateByUrl('/home');
};

  

}
