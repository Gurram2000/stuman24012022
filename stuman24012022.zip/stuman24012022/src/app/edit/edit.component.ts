import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { ServiceService } from '../service.service';
import { ActivatedRoute } from '@angular/router';
import Swal from 'sweetalert2';


@Component({
  selector: 'app-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.css']
})
export class EditComponent implements OnInit {
  section: any=['A','B','C'];



  constructor( private student: ServiceService, private router: ActivatedRoute ) { }

  editStudent=new FormGroup( {
    name: new FormControl( '' ),
    email: new FormControl( '' ),
    dept: new FormControl(''),
    sec: new FormControl(''),
  } );
  message: boolean=false;
  ngOnInit(): void {
    //console.log( this.router.snapshot.params.id );
    this.student.getStudentById( this.router.snapshot.params['id'] ).subscribe( ( result: any ) => {
      //console.log( result );
      this.editStudent=new FormGroup( {
        name: new FormControl( result['name'] ),
        email: new FormControl( result['email'] ),
        dept: new FormControl( result['dept'] ),
        sec: new FormControl( result['sec'] ),

      } );
    } );
  }

  UpdateData() {

    this.student.updateStudentData( this.router.snapshot.params['id'], this.editStudent.value ).subscribe( ( result) => {
      //console.log( result );
      this.message=true;
    } )
    Swal.fire({  
      position: 'top',  
      icon: 'success',  
      title: 'DATA IS SUCESSFULLY UPDATED',  
      
      
    })  
  }
  removeMessage() {
    this.message=false;
  }

}
